harmless test payload
